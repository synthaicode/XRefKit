"""Windows host identity, admission state and Responses HTTP transport."""
from __future__ import annotations

from contextlib import closing, contextmanager
import csv
import ctypes
from http.client import HTTPSConnection
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
from uuid import UUID


def _local_rollout(thread: str) -> Path:
    if str(UUID(thread)) != thread:
        raise ValueError("invalid Codex thread identity")
    home = Path(os.environ.get("CODEX_HOME") or Path.home() / ".codex")
    matches = list((home / "sessions").rglob(f"rollout-*{thread}.jsonl"))
    if len(matches) != 1:
        raise ValueError("expected one local Codex rollout")
    return matches[0]


def _read_abort(path: Path, turn: str, offset: int) -> tuple[bool, int]:
    with path.open("rb") as stream:
        if stream.seek(0, os.SEEK_END) < offset:
            offset = 0
        stream.seek(offset)
        for line in stream:
            if not line.endswith(b"\n"):
                break
            offset += len(line)
            try:
                record = json.loads(line)
            except (ValueError, UnicodeError):
                continue
            if not isinstance(record, dict) or record.get("type") != "event_msg":
                continue
            payload = record.get("payload")
            if (isinstance(payload, dict) and payload.get("type") == "turn_aborted"
                    and payload.get("turn_id") == turn):
                return True, offset - len(line)
    return False, offset


def _background_request(method: str, path: str, timeout: float, body: dict | None = None, *, project=None):
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        raise ValueError("missing provider credential")
    with closing(HTTPSConnection("api.openai.com", timeout=timeout)) as connection:
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        if project is not None:
            headers["OpenAI-Project"] = project
        connection.request(method, path, None if body is None else json.dumps(body).encode(), headers)
        response = connection.getresponse()
        raw = response.read(1_048_577)
        if len(raw) > 1_048_576:
            raise ValueError("background response exceeds limit")
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise ValueError("invalid background response")
        return response.status, payload


def _profile_path():
    root = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ".local" / "state")
    return root / "XRefKit" / "desktop-api-host.sqlite"


@contextmanager
def _admission():
    """Serialize rollback with Desktop Runtime admission across journals."""
    profile = _profile_path()
    profile.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(profile, timeout=10)) as database, database:
        database.execute("BEGIN IMMEDIATE")
        database.execute(
            "CREATE TABLE IF NOT EXISTS desktop_admission_v1 ("
            "id INTEGER PRIMARY KEY CHECK (id = 1), enabled INTEGER NOT NULL CHECK (enabled IN (0, 1)))"
        )
        yield database


def _set_admission(enabled: bool) -> dict:
    with _admission() as database:
        database.execute(
            "INSERT INTO desktop_admission_v1 VALUES (1, ?) "
            "ON CONFLICT(id) DO UPDATE SET enabled = excluded.enabled", (enabled,),
        )
    return {"status": "enabled" if enabled else "rolled_back"}


def _rollback_stop(execution: str, *, legacy: bool = False) -> None:
    """Apply a Stop once, atomically with its receipt in the admission profile."""
    with _admission() as db:
        db.execute("CREATE TABLE IF NOT EXISTS desktop_rollback_v1 (execution TEXT PRIMARY KEY)")
        first = db.execute("INSERT INTO desktop_rollback_v1 VALUES (?) ON CONFLICT DO NOTHING",
                           (execution,)).rowcount
        if first:
            # An old Stop has no rollback receipt. Preserve any explicit profile
            # decision in that case; an untouched profile still needs rollback.
            db.execute("INSERT INTO desktop_admission_v1 VALUES (1, 0) "
                       "ON CONFLICT(id) DO UPDATE SET enabled=0 WHERE ?=0", (legacy,))


def authenticated_owner():
    if os.name != "nt":
        return None
    directory = ctypes.create_unicode_buffer(32768)
    length = ctypes.windll.kernel32.GetSystemDirectoryW(directory, len(directory))
    if not 0 < length < len(directory):
        return None
    try:
        output = subprocess.run(
            [str(Path(directory.value) / "whoami.exe"), "/user", "/fo", "csv", "/nh"],
            capture_output=True, check=True, timeout=5,
        ).stdout.decode("mbcs")
        identity, = csv.reader(output.splitlines())
        sid = identity[1]
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        return None
    return sid if re.fullmatch(r"S-1-(?:[0-9]+-)*[0-9]+", sid) else None
