"""Keep watching a previously admitted local turn after the launcher stops waiting."""

from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from time import monotonic, sleep

from . import desktop_host as host
from .desktop_dispatch import record_verified_stop
from .desktop_responses import ResponsesTransport


def watch_local_stop(
    rollout: Path, journal: Path, execution: str, thread: str, turn: str, until: float, *,
    cancel_project: str | None = None, cancel_before: float | None = None,
    cancel_timeout: float | None = None, rollback: bool = False, watch_attempt: str | None = None,
) -> None:
    offset = 0
    stopped = False
    cancel = None
    if cancel_project and cancel_before and cancel_timeout:
        def cancel(response_id):
            remaining = cancel_before - monotonic()
            if remaining <= 0:
                raise TimeoutError("cancellation deadline expired")
            return ResponsesTransport(
                cancel_project, lambda _: None, min(remaining, cancel_timeout),
            ).cancel(response_id)

    while monotonic() < until:
        try:
            if not stopped:
                stopped, offset = host._read_abort(rollout, turn, offset)
            if stopped:
                record_verified_stop(
                    journal, execution, thread, turn, cancel=cancel, cancel_before=cancel_before,
                    watch_attempt=watch_attempt, watch_until=until,
                    rollback_stop=host._rollback_stop if rollback else None,
                )
                return
        except (OSError, sqlite3.Error):
            # A missing source or inaccessible journal is not a Stop notification.
            pass
        sleep(0.1)


def launch_stop_watch(
    rollout: Path, journal: Path, execution: str, thread: str, turn: str, seconds: float, *,
    cancel_project: str | None = None, cancel_before: float | None = None,
    cancel_timeout: float | None = None, rollback: bool = False, watch_attempt: str | None = None,
):
    package_path = Path(__file__).resolve().parent.parent
    code = (
        "import json, sys; from pathlib import Path; sys.path.insert(0, sys.argv[1]); "
        "from xrefkit_openai_runtime.desktop_stop_watch import watch_local_stop; "
        "watch_local_stop(Path(sys.argv[2]), Path(sys.argv[3]), *sys.argv[4:7], float(sys.argv[7]), **json.loads(sys.argv[8]))"
    )
    uri = journal.resolve().as_uri() + "?mode=rw"
    with closing(sqlite3.connect(uri, uri=True)) as db, db:
        if watch_attempt is None:
            db.execute("CREATE TABLE IF NOT EXISTS desktop_stop_watch_v1 (execution TEXT PRIMARY KEY)")
            inserted = db.execute("INSERT INTO desktop_stop_watch_v1 VALUES (?) ON CONFLICT DO NOTHING",
                                  (execution,)).rowcount
        else:
            db.execute("CREATE TABLE IF NOT EXISTS desktop_attempt_watch_v1 (attempt_id TEXT PRIMARY KEY)")
            inserted = db.execute("INSERT INTO desktop_attempt_watch_v1 VALUES (?) ON CONFLICT DO NOTHING",
                                  (watch_attempt,)).rowcount
        if not inserted:
            return
        until = monotonic() + seconds
        if cancel_project and cancel_before and cancel_timeout:
            until = max(until, cancel_before)
        subprocess.Popen(
            [sys.executable, "-I", "-B", "-c", code, str(package_path), str(rollout), str(journal),
             execution, thread, turn, str(until), json.dumps({
                 "cancel_project": cancel_project,
                 "cancel_before": cancel_before,
                 "cancel_timeout": cancel_timeout, "rollback": rollback, "watch_attempt": watch_attempt,
             })],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            start_new_session=os.name != "nt",
        )
