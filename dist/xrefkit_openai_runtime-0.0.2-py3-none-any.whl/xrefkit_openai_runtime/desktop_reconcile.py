"""Audit owner-authorized retrieval and settle the original Desktop response."""

from collections.abc import Callable
from contextlib import closing
from pathlib import Path
import sqlite3

from .desktop_dispatch import ProviderReceipt, _SETTLED_COST, apply_retrieved_receipt


def reconcile_usage(
    journal: Path, execution: str, thread: str, turn: str, owner: str | None,
    retrieve: Callable[[str], ProviderReceipt] | None,
) -> dict:
    denied = {"status": "hold_reconciliation", "reason": "owner_or_binding_unverified"}
    if owner is None or not journal.is_file():
        return denied
    uri = journal.resolve().as_uri() + "?mode=rw"
    with closing(sqlite3.connect(uri, uri=True)) as db:
        with db:
            db.execute("BEGIN IMMEDIATE")
            tables = {name for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
            if not {"desktop_request_v1", "desktop_owner_v1", "desktop_submission_v1"} <= tables:
                return denied
            submission = db.execute(f"""
                SELECT s.response_id, s.provider_status, {_SETTLED_COST}
                FROM desktop_request_v1 q JOIN desktop_owner_v1 o USING (execution)
                JOIN desktop_submission_v1 s USING (execution)
                WHERE q.execution = ? AND q.thread = ? AND q.turn = ? AND o.owner = ?
            """, (execution, thread, turn, owner)).fetchone()
            if submission is None:
                return denied
            response_id, status, cost = submission
            recorded = {"execution_id": execution, "response_id": response_id, "provider_status": status,
                       "cost_microusd": cost}
            if cost is not None and (status != "completed" or _has_result(db, execution)):
                return dict(recorded, status="settled")
            if not response_id or retrieve is None:
                return dict(recorded, status="hold_reconciliation",
                            reason="response_unconfirmed" if not response_id else "retrieval_unavailable")
            db.execute("""
                CREATE TABLE IF NOT EXISTS desktop_usage_audit_v1 (
                    attempt INTEGER PRIMARY KEY, execution TEXT NOT NULL, owner TEXT NOT NULL,
                    response_id TEXT NOT NULL, requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    finished_at TEXT, outcome TEXT NOT NULL DEFAULT 'lookup_requested'
                )
            """)
            attempt = db.execute(
                "INSERT INTO desktop_usage_audit_v1(execution, owner, response_id) VALUES (?, ?, ?)",
                (execution, owner, response_id),
            ).lastrowid
        try:
            receipt = retrieve(response_id)
        except (OSError, ValueError):
            receipt = None
        with db:
            db.execute("BEGIN IMMEDIATE")
            current_status, current_cost = db.execute(
                f"SELECT provider_status, {_SETTLED_COST} FROM desktop_submission_v1 WHERE execution = ?", (execution,),
            ).fetchone()
            if receipt is None:
                outcome = {"status": "hold_reconciliation", "reason": "retrieval_unconfirmed"}
            else:
                outcome = apply_retrieved_receipt(db, execution, receipt)
            audit_outcome = outcome.get("reason", outcome["status"])
            if current_cost is not None:
                # A competing owner read may have settled while this read was in flight.
                outcome = recorded | outcome | {"provider_status": current_status, "cost_microusd": current_cost}
                if audit_outcome == "settled":
                    audit_outcome = "already_settled"
            if (outcome.get("provider_status") == "completed" and outcome.get("cost_microusd") is not None
                    and not _has_result(db, execution)):
                outcome = dict(outcome, status="hold_reconciliation", reason=outcome.get("reason", "result_unavailable"))
                if audit_outcome == "already_settled":
                    audit_outcome = "result_unavailable"
            db.execute(
                "UPDATE desktop_usage_audit_v1 SET outcome = ?, finished_at = CURRENT_TIMESTAMP WHERE attempt = ?",
                (audit_outcome, attempt),
            )
        return outcome


def _has_result(db, execution):
    # Older journals create the result table lazily on first saved output.
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='desktop_result_v1'").fetchone():
        return False
    return db.execute("SELECT 1 FROM desktop_result_v1 WHERE execution=?", (execution,)).fetchone() is not None
