"""Convert Responses API operations into correlated Desktop receipts."""

from collections.abc import Callable
from dataclasses import dataclass
from http.client import HTTPException
import re

from . import desktop_host as host
from .desktop_admission import Request
from .desktop_dispatch import BudgetQuote, DesktopDispatch, ProviderReceipt, _TERMINAL


_STATUS = _TERMINAL | {"queued", "in_progress"}


@dataclass(frozen=True)
class ResponsesTransport:
    project: str
    estimate_cost: Callable[[dict], int | None]
    timeout: float
    max_output_tokens: int | None = None

    def dispatch(
        self, quote: Callable[[Request], BudgetQuote], *, cancel_before: float | None = None,
        deliver: Callable[[str, str, str], bool] | None = None,
    ) -> DesktopDispatch:
        return DesktopDispatch(
            quote, self.submit, deliver=deliver, cancel=self.cancel, cancel_before=cancel_before,
            retrieve=self.retrieve, cancel_project=self.project, cancel_timeout=self.timeout,
        )

    def submit(self, execution: str, request: Request) -> ProviderReceipt:
        body = {"model": request.model, "input": request.text, "background": True, "store": True,
                "service_tier": "default"}
        if self.max_output_tokens is not None:
            body["max_output_tokens"] = self.max_output_tokens
        return self._request("POST", "/v1/responses", body=body)

    def retrieve(self, response_id: str) -> ProviderReceipt:
        return self._request("GET", _response_path(response_id), expected_id=response_id)

    def cancel(self, response_id: str) -> ProviderReceipt:
        return self._request("POST", _response_path(response_id) + "/cancel", expected_id=response_id)

    def _request(self, method: str, path: str, *, expected_id=None, body=None) -> ProviderReceipt:
        try:
            http, payload = host._background_request(method, path, self.timeout, body, project=self.project)
        except (HTTPException, ValueError, OSError) as error:
            raise OSError("Responses request outcome unconfirmed") from error
        if http != 200:
            raise OSError(f"Responses request was not accepted (HTTP {http})")
        response_id, status = payload.get("id"), payload.get("status")
        _response_path(response_id)
        if (expected_id is not None and response_id != expected_id
                or not isinstance(status, str) or status not in _STATUS):
            raise OSError("Responses receipt does not match the requested operation")

        usage = payload.get("usage")
        cost = None
        if isinstance(usage, dict) and status in _TERMINAL:
            try:
                cost = self.estimate_cost(payload)
            except ValueError:
                # Failed pricing must not discard the original response identity.
                pass
        return ProviderReceipt(
            response_id, status, cost, _text_output(payload) if status == "completed" else None,
            payload.get("background") is True,
        )


def _response_path(response_id) -> str:
    if not isinstance(response_id, str) or not re.fullmatch(r"resp_[A-Za-z0-9_-]+", response_id):
        raise OSError("Invalid Responses identity")
    return "/v1/responses/" + response_id


def _text_output(payload: dict) -> str | None:
    output = payload.get("output")
    if not isinstance(output, list):
        return None
    parts = []
    for item in output:
        if not isinstance(item, dict) or item.get("type") != "message" or item.get("role") != "assistant":
            continue
        content = item.get("content")
        if not isinstance(content, list):
            return None
        for part in content:
            if isinstance(part, dict) and part.get("type") == "output_text":
                value = part.get("text")
                if not isinstance(value, str):
                    return None
                parts.append(value)
    return "".join(parts) if parts else None
