"""Build a Responses transport from a purpose-specific Windows profile."""
from dataclasses import dataclass, replace
from http.client import HTTPException
import json
import os
from pathlib import Path
import re


from . import desktop_host as host
from .desktop_admission import _object
from .desktop_dispatch import BudgetQuote, GenerationNotSent
from .desktop_responses import ResponsesTransport


@dataclass(frozen=True)
class PurposePolicy:
    project: str
    purpose: str
    budget_microusd: int
    model: str
    max_lookups: int
    cancel_seconds: int
    max_input_tokens: int
    max_output_tokens: int
    input_nanousd_per_token: int
    output_nanousd_per_token: int

    standard_input_threshold: int
    input_ceiling_nanousd_per_token: int
    output_ceiling_nanousd_per_token: int

    @classmethod
    def read(cls, path: Path):
        data = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_object)
        if type(data) is not dict or set(data) != set(cls.__dataclass_fields__):
            raise ValueError("invalid purpose policy")
        if not isinstance(data["project"], str) or not re.fullmatch(r"proj_[A-Za-z0-9]+", data["project"]):
            raise ValueError("missing billing project")
        for field in ("purpose", "model"):
            if not isinstance(data[field], str) or not data[field].strip():
                raise ValueError("missing purpose or priced model")
        for field in data.keys() - {"project", "purpose", "model"}:
            if type(data[field]) is not int or not 0 < data[field] < 2**63:
                raise ValueError("invalid purpose budget or tariff")
        if (data['input_ceiling_nanousd_per_token'] < data['input_nanousd_per_token']
                or data['output_ceiling_nanousd_per_token'] < data['output_nanousd_per_token']):
            raise ValueError('maximum tariff below base tariff')
        return cls(**data)

    def quote(self, request):
        if request.model != self.model or not os.environ.get("OPENAI_API_KEY", "").strip():
            raise ValueError("effective model or credential unavailable")
        # The provider counts this exact model and input after reservation and before generation.
        reservation = (self.max_input_tokens * self.input_ceiling_nanousd_per_token
                       + self.max_output_tokens * self.output_ceiling_nanousd_per_token)
        return BudgetQuote(self.purpose, self.budget_microusd, (reservation + 999) // 1000)

    def cost(self, payload):
        usage = payload.get("usage")
        if (payload.get("model") != self.model or payload.get("service_tier") != "default"
                or not isinstance(usage, dict)):
            return None
        counts = (usage.get("input_tokens"), usage.get("output_tokens"))
        if any(type(n) is not int or n < 0 for n in counts):
            return None
        if counts[0] > min(self.standard_input_threshold, self.max_input_tokens) or counts[1] > self.max_output_tokens:
            return None
        # Discounted input needs its own approved tariff.
        details = usage.get("input_tokens_details")
        if not isinstance(details, dict) or "cached_tokens" not in details:
            return None
        writes = details.get("cache_write_tokens_details", {})
        counts_by_type = [value for key, value in details.items() if key != "cache_write_tokens_details"]
        if not isinstance(writes, dict) or any(
            type(value) is not int or value != 0 for value in (*counts_by_type, *writes.values())
        ):
            return None
        return (counts[0] * self.input_nanousd_per_token + counts[1] * self.output_nanousd_per_token + 999) // 1000

    def dispatch(self, *, deadline, can_generate=None):
        transport = ResponsesTransport(self.project, self.cost, 10, self.max_output_tokens).dispatch(
            self.quote, cancel_before=deadline,
        )
        if can_generate is None:
            return transport

        def checked_submit(execution, request):
            try:
                code, data = host._background_request(
                    "POST", "/v1/responses/input_tokens", 10, {"model": request.model, "input": request.text},
                    project=self.project,
                )
            except (HTTPException, ValueError, OSError) as exc:
                raise GenerationNotSent("input count unavailable") from exc
            count = data.get("input_tokens")
            if (code != 200 or data.get("object") != "response.input_tokens" or type(count) is not int
                    or not 0 <= count <= self.max_input_tokens or not can_generate()):
                raise GenerationNotSent("generation preflight did not pass")
            return transport.submit(execution, request)

        return replace(transport, submit=checked_submit)
