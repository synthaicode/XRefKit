"""Install the bundled Codex assignment instructions in a selected workspace."""
import argparse
from importlib.resources import files
from pathlib import Path
import sysconfig


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    workspace = args.workspace.resolve(strict=True)
    if not workspace.is_dir():
        parser.error("workspace must be a directory")
    relative = Path(".agents/skills/xrefkit-runtime-assignment/SKILL.md")
    target = workspace / relative
    if not target.resolve().is_relative_to(workspace):
        parser.error("skill location is outside the workspace")
    content = files("xrefkit_openai_runtime").joinpath(
        "codex_skills", "xrefkit-runtime-assignment", "SKILL.md",
    ).read_bytes()
    launcher = Path(sysconfig.get_path("scripts")) / "xrefkit-openai-runtime-desktop.exe"
    if not launcher.is_file():
        parser.error("the installed Windows Desktop launcher is missing")
    content = content.replace(b"the installed xrefkit-openai-runtime-desktop process",
                              ("the installed process at `" + str(launcher) + "`").encode("utf-8"))
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        with target.open("xb") as stream:
            stream.write(content)
    except FileExistsError:
        if target.read_bytes() != content:
            parser.error("an existing assignment skill differs from this distribution")
    print(target)
    return 0
