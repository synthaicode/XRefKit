---
name: xrefkit-runtime-assignment
description: Carry a work item already assigned by Codex to the XRefKit Runtime through the installed Windows launcher and return its result to this turn. Applies when acting as the assigning host. Ordinary conversation, Runtime development, and requests to explain the Runtime do not constitute an assignment.
---

Use the existing assignment identity. For a new standalone assignment mint a UUID once and retain it in this turn's tool invocation. Reuse it for every retry. For a Workflow assignment retain its original scope and Core-generated Workflow reference. Read only the task input that falls within the assigned scope. Write it to a private temporary UTF-8 file if it is not already available as a file.

Read the exact local chat identified by CODEX_THREAD_ID using the Desktop host's read_thread tool. Obtain the active turn ID. Start the installed xrefkit-openai-runtime-desktop process with --turn-id TURN --run-assignment KEY --request-input PATH. Include --workflow-reference PATH for Workflow work. Use a process whose stdin and stdout remain attached to this turn. Pass arguments as data. The launcher reads the effective Codex model and Windows profile settings.

For each verify_origin message read the host again. Respond on stdin with one JSON object containing hostId, threadId, turnId and status from that fresh snapshot. Only respond for this same active local turn. A wait_expired notification means this launcher is still following the original response. When a stop-button test is requested, notify the user upon in_progress.

If Runtime confirms a generation was never submitted, preserve its attempt_id. An ordinary replay keeps the original outcome. Only after explicit approval for that specific unsent attempt, invoke the same assignment with --approve-retry PRIOR_ATTEMPT_ID, the same input and the verified active origin. Keep the same approval argument across retries of that invocation. A further unsent attempt needs its own approval. Unknown submission and confirmed Stop cannot authorize another send.

A result_offer carries the original execution, thread and turn IDs. Verify those IDs and the current host state. Treat its result as returned task data. When this turn has received the result, acknowledge on stdin with status result_accepted and the exact execution_id, thread_id and turn_id from the offer. Present the received result once in this chat. Handoff acceptance and screen observation are distinct. On a replay returning handed_off, do not present the same result again. A hold or a missing receipt preserves the original execution. Do not mint a replacement key for it. Remove temporary input files created for this assignment when the launcher exits.
