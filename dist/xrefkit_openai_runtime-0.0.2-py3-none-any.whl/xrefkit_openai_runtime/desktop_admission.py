"""Configuration and request correlation for the Desktop Runtime boundary."""

from contextlib import closing
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
from tempfile import TemporaryDirectory
from uuid import UUID, uuid4

from .distribution import STARTUP_SHA256


class StartupContractMismatch(ValueError):
    """The inherited startup reference differs from the bundled identity."""


class WorkflowUnconfirmed(ValueError):
    """The supplied Workflow reference could not be confirmed by Core."""


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def api_enabled(path: Path | None) -> bool:
    if path is None:
        return False
    config = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_object)
    if type(config) is not dict or set(config) != {"enabled"} or type(config["enabled"]) is not bool:
        raise ValueError("invalid Desktop API configuration")
    return config["enabled"]


@dataclass(frozen=True)
class WorkflowReference:
    log: Path
    scope: str
    binding: dict

    @classmethod
    def read(cls, data) -> "WorkflowReference":
        if type(data) is not dict or set(data) != {"log", "scope", "binding"}:
            raise WorkflowUnconfirmed("invalid Workflow reference")
        log, scope, binding = (data[key] for key in ("log", "scope", "binding"))
        if type(log) is not str or not Path(log).is_absolute() or type(scope) is not str or not scope.strip():
            raise WorkflowUnconfirmed("Workflow requires a local log path and scope")
        if type(binding) is not dict or binding.get("binding_origin") != "workflow_builder":
            raise WorkflowUnconfirmed("Workflow requires a Core-generated Binding")
        return cls(Path(log), scope, binding)

    def verify(self, core_python: str) -> None:
        # Rebuild against the current log so Core owns snapshot and work-item validation.
        generated_fields = {"binding_origin", "definition_identity", "run_id", "run_snapshot", "schema_version"}
        request = {key: value for key, value in self.binding.items() if key not in generated_fields}
        with TemporaryDirectory(prefix="xrefkit-binding-") as temp:
            path = Path(temp) / "request.json"
            path.write_text(json.dumps(request, allow_nan=False), encoding="utf-8")
            try:
                result = subprocess.run(
                    [core_python, "-I", "-B", "-m", "xrefkit", "workflow", "bind-execution",
                     "--log", str(self.log), "--request", str(path), "--json"],
                    capture_output=True, timeout=30, check=True,
                )
            except subprocess.SubprocessError as exc:
                raise ValueError("Core did not confirm the Workflow Binding") from exc
        rebuilt = json.loads(result.stdout, object_pairs_hook=_object)
        if json.dumps(rebuilt, sort_keys=True) != json.dumps(self.binding, sort_keys=True):
            raise ValueError("Workflow Binding changed")
        if self.scope not in rebuilt["scope_in"] or self.scope in rebuilt["scope_out"]:
            raise ValueError("requested scope is outside the Workflow Binding")


@dataclass(frozen=True)
class Request:
    request_id: str
    model: str
    text: str
    workflow: WorkflowReference | None = None

    @classmethod
    def from_files(cls, request_id: str, model: str, input_path: Path,
                   workflow_path: Path | None) -> "Request":
        text = input_path.read_text(encoding="utf-8-sig")
        if not text.strip() or str(UUID(request_id)) != request_id:
            raise ValueError("invalid request input or ID")
        workflow = None
        if workflow_path is not None:
            try:
                data = json.loads(workflow_path.read_text(encoding="utf-8-sig"), object_pairs_hook=_object)
            except (OSError, ValueError) as exc:
                raise WorkflowUnconfirmed("unreadable Workflow reference") from exc
            workflow = WorkflowReference.read(data)
        return cls(request_id, model, text, workflow)

    @classmethod
    def read(cls, line: str, thread: str, turn: str) -> "Request":
        data = json.loads(line, object_pairs_hook=_object)
        required = {"schema_version", "hostId", "threadId", "turnId", "status",
                    "request_id", "model", "input", "startup_xid", "startup_sha256"}
        if type(data) is not dict or not required <= data.keys() or data.keys() - required - {"workflow"}:
            raise ValueError("invalid Desktop request")
        if type(data["schema_version"]) is not int or data["schema_version"] != 1:
            raise ValueError("unsupported Desktop request schema")
        if (data["hostId"], data["threadId"], data["turnId"], data["status"]) != (
            "local", thread, turn, "inProgress"
        ):
            raise ValueError("Desktop origin mismatch")
        if (data["startup_xid"], data["startup_sha256"]) != ("C3A1F78D9B22", STARTUP_SHA256):
            raise StartupContractMismatch("startup contract mismatch")
        request_id, model, text = (data[key] for key in ("request_id", "model", "input"))
        if not all(isinstance(value, str) and value.strip() for value in (request_id, model, text)):
            raise ValueError("missing Desktop request data")
        if str(UUID(request_id)) != request_id:
            raise ValueError("invalid request ID")
        workflow = WorkflowReference.read(data["workflow"]) if "workflow" in data else None
        return cls(request_id, model, text, workflow)

    def acquire(self, journal: Path, thread: str, turn: str, *, owner: str | None = None,
                existing_only: bool = False) -> tuple[str, bool]:
        """Correlate an already verified request without persisting its text."""
        identity = [self.model, self.text]
        if self.workflow is not None:
            identity.append([str(self.workflow.log), self.workflow.scope, self.workflow.binding])
        encoded = json.dumps(identity, ensure_ascii=True, sort_keys=True, allow_nan=False).encode("ascii")
        digest = hashlib.sha256(encoded).hexdigest()
        execution = uuid4().hex
        with closing(sqlite3.connect(journal)) as db, db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS desktop_request_v1 (
                    request TEXT PRIMARY KEY, thread TEXT NOT NULL, turn TEXT NOT NULL,
                    digest TEXT NOT NULL, execution TEXT NOT NULL
                )
            """)
            created = not existing_only and db.execute(
                "INSERT INTO desktop_request_v1 VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(request) DO NOTHING",
                (self.request_id, thread, turn, digest, execution),
            ).rowcount == 1
            prior = db.execute(
                "SELECT thread, turn, digest, execution FROM desktop_request_v1 WHERE request = ?",
                (self.request_id,),
            ).fetchone()
            if prior is None:
                raise ValueError("original Desktop assignment unconfirmed")
            prior_thread, prior_turn, prior_digest, existing = prior
            if (prior_thread, prior_turn, prior_digest) != (thread, turn, digest):
                raise ValueError("conflicting Desktop request")
            if created and owner is not None:
                db.execute("""
                    CREATE TABLE IF NOT EXISTS desktop_owner_v1 (
                        execution TEXT PRIMARY KEY, owner TEXT NOT NULL
                    )
                """)
                db.execute("INSERT INTO desktop_owner_v1 VALUES (?, ?)", (execution, owner))
        return existing, created


def effective_model(path: Path, turn: str) -> str:
    """Read the observed Windows turn-context shape without exporting history."""
    model = None
    with path.open("rb") as stream:
        for line in stream:
            if not line.endswith(b"\n"):
                break
            event = json.loads(line)
            if event.get("type") == "turn_context" and event["payload"].get("turn_id") == turn:
                observed = event["payload"].get("model")
                if not isinstance(observed, str) or not observed.strip() or (model is not None and observed != model):
                    raise ValueError("effective Desktop model unavailable")
                model = observed
    if model is None:
        raise ValueError("effective Desktop model unavailable")
    return model
