"""Durable handoff of a saved result to its originating Desktop turn."""

from collections.abc import Callable
from contextlib import closing
from pathlib import Path
import sqlite3

from . import desktop_host as host
from .desktop_dispatch import restore_stop_for_recovery


def _has_stop(db, execution):
    table = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='desktop_stop_v1'").fetchone()
    return bool(table and db.execute("SELECT 1 FROM desktop_stop_v1 WHERE execution=?", (execution,)).fetchone())


def handoff_result(
    journal: Path, execution: str, thread: str, turn: str,
    origin_active: Callable[[], bool], deliver: Callable[[str, str, str], bool],
) -> str:
    """Use a host-scoped delivery callback that acknowledges acceptance, not display."""
    if not origin_active():
        return "origin_unconfirmed"
    with closing(sqlite3.connect(journal)) as db:
        with db:
            db.execute("BEGIN IMMEDIATE")
            origin = db.execute(
                "SELECT thread, turn FROM desktop_request_v1 WHERE execution = ?", (execution,),
            ).fetchone()
            if origin != (thread, turn):
                return "origin_unconfirmed"
            if _has_stop(db, execution):
                return "origin_stopped"
            if db.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'desktop_result_v1'"
            ).fetchone() is None:
                return "result_unavailable"
            result = db.execute(
                "SELECT result_text FROM desktop_result_v1 WHERE execution = ?", (execution,),
            ).fetchone()
            if result is None:
                return "result_unavailable"
            db.execute("""
                CREATE TABLE IF NOT EXISTS desktop_handoff_v1 (
                    execution TEXT PRIMARY KEY, completed INTEGER NOT NULL DEFAULT 0
                )
            """)
            prior = db.execute(
                "SELECT completed FROM desktop_handoff_v1 WHERE execution = ?", (execution,),
            ).fetchone()
            if prior is not None:
                return "handed_off" if prior[0] else "handoff_unconfirmed"
            db.execute("INSERT INTO desktop_handoff_v1(execution) VALUES (?)", (execution,))

        # The host may have stopped while this process waited for the claim.
        active = origin_active()
        stopped = _has_stop(db, execution)
        if not active or stopped:
            # This claimant has not called deliver, so its own claim is safe to release.
            with db:
                db.execute("DELETE FROM desktop_handoff_v1 WHERE execution=? AND completed=0", (execution,))
            return "origin_stopped" if stopped else "origin_unconfirmed"
        if not deliver(thread, turn, result[0]):
            return "handoff_unconfirmed"
        with db:
            db.execute("UPDATE desktop_handoff_v1 SET completed = 1 WHERE execution = ?", (execution,))
        return "handed_off"


def _bound_result(db, execution, thread, turn, owner):
    tables = {name for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    if not {"desktop_request_v1", "desktop_owner_v1", "desktop_result_v1"} <= tables:
        return None
    return db.execute("""
        SELECT r.result_text FROM desktop_request_v1 q
        JOIN desktop_owner_v1 o USING (execution)
        JOIN desktop_result_v1 r USING (execution)
        WHERE q.execution = ? AND q.thread = ? AND q.turn = ? AND o.owner = ?
    """, (execution, thread, turn, owner)).fetchone()


def recover_saved_result(
    journal: Path, execution: str, thread: str, turn: str, owner: str | None, *,
    verify_abort: Callable[[], bool] | None = None,
) -> dict:
    """Return the original saved result after verifying a durable host Stop and its owner."""
    denied = {"status": "hold", "reason": "saved_result_unavailable"}
    if owner is None or not journal.is_file():
        return denied
    with closing(sqlite3.connect(journal.resolve().as_uri() + "?mode=rw", uri=True)) as db, db:
        if verify_abort is not None:
            db.execute("BEGIN IMMEDIATE")
            if _bound_result(db, execution, thread, turn, owner) is None:
                return denied
            legacy = restore_stop_for_recovery(db, execution, verify_abort)
            if legacy is None:
                return denied
            # A failed profile write or audit must not erase the observed host Stop.
            db.commit()
            host._rollback_stop(execution, legacy=legacy)
        db.execute("BEGIN IMMEDIATE")
        saved = _bound_result(db, execution, thread, turn, owner)
        if saved is None or not _has_stop(db, execution):
            return denied
        db.execute("""
            CREATE TABLE IF NOT EXISTS desktop_recovery_audit_v1 (
                execution TEXT NOT NULL, owner TEXT NOT NULL,
                accessed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute(
            "INSERT INTO desktop_recovery_audit_v1(execution, owner) VALUES (?, ?)",
            (execution, owner),
        )
        return {"status": "result_recovered", "execution_id": execution, "result": saved[0]}
