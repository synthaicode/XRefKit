"""Run assigned work and recover saved outcomes from the Windows Desktop profile."""

from __future__ import annotations

import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
from time import monotonic, sleep, time
from uuid import UUID, uuid5

from . import desktop_host as host
from .acquisition import AcquisitionCancelled, AcquisitionError, resolve_core
from .desktop_policy import PurposePolicy
from .desktop_stop_watch import launch_stop_watch
from .desktop_reconcile import reconcile_usage
from .desktop_handoff import handoff_result, recover_saved_result
from .desktop_admission import Request, StartupContractMismatch, WorkflowUnconfirmed, api_enabled, effective_model
from .distribution import CORE_LOCK, CORE_LOCK_SHA256, STARTUP_CONTRACT, STARTUP_SHA256


_STARTUP_XID = "C3A1F78D9B22"


def _acquisition_stop(thread: str, turn: str):
    rollout = host._local_rollout(thread)
    offset = 0
    checked_at = float("-inf")
    stopped = False

    def stopped_by_host(*, force=False):
        nonlocal offset, checked_at, stopped
        now = monotonic()
        if not stopped and (force or now - checked_at >= 0.1):
            stopped, offset = host._read_abort(rollout, turn, offset)
            checked_at = now
        return stopped

    return stopped_by_host


def _core_startup(args: argparse.Namespace, stop_requested, *, workflow=None) -> dict:
    try:
        with args.core_startup_file.open("rb") as stream:
            content = stream.read(20001)
    except OSError as exc:
        raise StartupContractMismatch("bundled startup contract is unavailable") from exc
    digest = hashlib.sha256(content).hexdigest()
    if (
        len(content) > 20000 or digest != args.core_startup_sha256
        or f"<!-- xid: {_STARTUP_XID} -->" not in content.decode("utf-8-sig").splitlines()
    ):
        raise StartupContractMismatch("Core startup contract does not match the reviewed source")
    ready = resolve_core(
        args.core_lock, local_python=args.core_python, cache_dir=args.core_cache_dir,
        wheelhouse=args.core_wheelhouse, offline=True, stop_requested=stop_requested,
        expected_lock_sha256=CORE_LOCK_SHA256,
    )
    if workflow is not None:
        if stop_requested():
            raise AcquisitionCancelled("origin stopped before Workflow verification")
        try:
            workflow.verify(ready["python"])
        except (ValueError, OSError, TypeError, KeyError) as exc:
            raise WorkflowUnconfirmed("Core did not confirm the Workflow reference") from exc
    return {
        "status": "core_runtime_ready",
        "source": ready["source"],
        "version": ready["version"],
        "target": ready["target"],
        "binding_schema_version": ready["binding_schema_version"],
        "lock_sha256": ready["lock_sha256"],
        "startup_xid": _STARTUP_XID,
        "startup_sha256": digest,
    }


def _emit(payload: dict) -> None:
    print(json.dumps(payload), flush=True)


def _origin(thread: str, turn: str) -> bool:
    _emit({"status": "verify_origin", "thread_id": thread, "turn_id": turn})
    try:
        snapshot = json.loads(input())
    except (EOFError, ValueError):
        return False
    return isinstance(snapshot, dict) and (
        snapshot.get("hostId"), snapshot.get("threadId"), snapshot.get("turnId"), snapshot.get("status")
    ) == ("local", thread, turn, "inProgress")


def _deliver_saved(execution: str, thread: str, turn: str) -> dict:
    """Offer a saved result on the originating host exchange and record its receipt."""
    ledger = _desktop_journal()
    owner = host.authenticated_owner()
    if not owner or not ledger.is_file():
        return {"status": "hold", "reason": "saved_result_unavailable"}
    with closing(sqlite3.connect(ledger.resolve().as_uri() + "?mode=ro", uri=True)) as db:
        authorized = db.execute(
            "SELECT 1 FROM desktop_request_v1 r JOIN desktop_owner_v1 o USING (execution) "
            "WHERE r.execution=? AND r.thread=? AND r.turn=? AND o.owner=?",
            (execution, thread, turn, owner),
        ).fetchone()
    if not authorized:
        return {"status": "hold", "reason": "saved_result_unavailable"}
    stopped = _acquisition_stop(thread, turn)

    def accept_result(target_thread, target_turn, text):
        _emit({"status": "result_offer", "execution_id": execution, "thread_id": target_thread,
               "turn_id": target_turn, "result": text})
        try:
            receipt = json.loads(input())
        except (EOFError, OSError, ValueError):
            return False
        return receipt == {"status": "result_accepted", "execution_id": execution,
                           "thread_id": target_thread, "turn_id": target_turn}

    status = handoff_result(ledger, execution, thread, turn,
                            lambda: _origin(thread, turn) and not stopped(force=True), accept_result)
    return {"status": status, "execution_id": execution}


def _desktop_journal() -> Path:
    return host._profile_path().with_name("desktop-runtime.sqlite")


def _check_admission(args: argparse.Namespace, thread: str, turn: str, *, dispatch=None) -> int:
    try:
        enabled = api_enabled(args.api_config)
    except (OSError, ValueError):
        _emit({"status": "hold", "reason": "invalid_api_configuration"})
        return 2
    if not enabled:
        _emit({"status": "hold", "reason": "api_disabled"})
        return 2
    try:
        rollout = host._local_rollout(thread)
        if args.request_input is None:
            _emit({"status": "verify_origin", "thread_id": thread, "turn_id": turn,
                   "request_schema_version": 1})
            request = Request.read(input(), thread, turn)
            if request.model != effective_model(rollout, turn):
                raise ValueError("effective Desktop model mismatch")
        else:
            if not _origin(thread, turn):
                raise ValueError("origin unconfirmed")
            request = Request.from_files(
                args.request_id, effective_model(rollout, turn), args.request_input, args.workflow_reference,
            )
        stopped = _acquisition_stop(thread, turn)
        if stopped():
            raise AcquisitionCancelled("origin stopped before Core acquisition")
        args.core_startup_file = STARTUP_CONTRACT
        args.core_startup_sha256 = STARTUP_SHA256
        args.core_lock = CORE_LOCK
        try:
            ready = _core_startup(args, stopped, workflow=request.workflow)
        except (StartupContractMismatch, WorkflowUnconfirmed):
            raise
        except (OSError, KeyError, ValueError, TypeError) as exc:
            raise AcquisitionError("Core startup unavailable") from exc
        if stopped(force=True):
            raise AcquisitionCancelled("origin stopped during Core acquisition")
        if not _origin(thread, turn):
            raise ValueError("origin closed during Core acquisition")
        if stopped(force=True):
            raise AcquisitionCancelled("origin stopped during origin verification")
        if effective_model(rollout, turn) != request.model:
            raise ValueError("effective Desktop model changed during Core acquisition")
        _emit(ready)
        ledger = args.journal
        if args.admit_assignment is not None:
            owner = host.authenticated_owner()
            if not owner:
                raise ValueError("authenticated Windows owner required")
            ledger.parent.mkdir(parents=True, exist_ok=True)
            execution, created = request.acquire(ledger, thread, turn, owner=owner,
                                                existing_only=args.approve_retry is not None)
            with closing(sqlite3.connect(ledger)) as db:
                if db.execute("SELECT owner FROM desktop_owner_v1 WHERE execution=?", (execution,)).fetchone() != (owner,):
                    raise ValueError("original Windows owner unconfirmed")
        elif dispatch is None:
            execution, created = request.acquire(ledger, thread, turn)
        else:
            # Request, budget, owner and recovery evidence share the Windows profile journal.
            ledger = _desktop_journal()
            ledger.parent.mkdir(parents=True, exist_ok=True)
            execution, created = request.acquire(
                ledger, thread, turn, owner=host.authenticated_owner(),
            )
        if args.run_assignment is not None:
            policy = PurposePolicy.read(ledger.with_name("desktop-purpose.json"))
            with closing(sqlite3.connect(ledger)) as db, db:
                db.execute("BEGIN IMMEDIATE")
                db.execute("""CREATE TABLE IF NOT EXISTS desktop_authority_v1 (
                    execution TEXT PRIMARY KEY, policy TEXT NOT NULL, expires REAL NOT NULL,
                    lookups INTEGER NOT NULL DEFAULT 0)""")
                terms = json.dumps(vars(policy), sort_keys=True)
                if args.approve_retry is None:
                    db.execute("INSERT INTO desktop_authority_v1(execution, policy, expires) "
                               "VALUES (?, ?, ?) ON CONFLICT DO NOTHING",
                               (execution, terms, time() + policy.cancel_seconds))
                authority = db.execute(
                    "SELECT policy, expires FROM desktop_authority_v1 WHERE execution=?", (execution,),
                ).fetchone()
                if authority is None or authority[0] != terms:
                    raise ValueError("purpose policy changed for an existing assignment")
                expires = authority[1]
            dispatch = policy.dispatch(deadline=monotonic() + max(0, expires - time()),
                                       can_generate=lambda: can_send())
        if dispatch is not None:
            def can_send():
                if (not api_enabled(args.api_config) or stopped(force=True)
                        or args.run_assignment is not None and time() >= expires):
                    return False
                with host._admission() as profile:
                    return profile.execute(
                        "SELECT enabled FROM desktop_admission_v1 WHERE id = 1"
                    ).fetchone() != (0,)

            def arm_watch(attempt):
                launch_stop_watch(rollout, ledger, execution, thread, turn, args.reconcile_seconds,
                                  cancel_project=dispatch.cancel_project, cancel_before=dispatch.cancel_before,
                                  cancel_timeout=dispatch.cancel_timeout, rollback=True, watch_attempt=attempt)

            result = dispatch.execute(
                ledger, execution, request, can_send, retry_of=args.approve_retry,
                arm_watch=arm_watch if args.run_assignment is not None else None,
                stopped_origin=lambda: (thread, turn) if stopped(force=True) else None,
            )
            attempt = result.get("attempt_id")
            if args.run_assignment is not None and result.get("provider_status") in {"queued", "in_progress"}:
                if attempt:
                    arm_watch(attempt)  # Adopt a replayed pre-watcher claim.
                wait_until = min(expires, time() + args.wait_seconds + args.reconcile_seconds)
                first_wait = time() + args.wait_seconds
                notified_delay = False
                notified_progress = False
                next_lookup = time()
                while time() < wait_until and not stopped(force=True):
                    if result.get("provider_status") == "in_progress" and not notified_progress:
                        _emit({"status": "in_progress", "execution_id": execution})
                        notified_progress = True
                    if time() >= first_wait and not notified_delay:
                        _emit({"status": "wait_expired", "execution_id": execution})
                        notified_delay = True
                    if time() < next_lookup:
                        sleep(max(0, min(0.1, next_lookup - time())))
                        continue
                    with closing(sqlite3.connect(ledger)) as db, db:
                        claim = db.execute("UPDATE desktop_authority_v1 SET lookups=lookups+1 "
                                             "WHERE execution=? AND lookups<? AND expires>? RETURNING lookups",
                                           (execution, policy.max_lookups, time())).fetchone()
                    if claim is None:
                        break
                    result = reconcile_usage(ledger, execution, thread, turn, owner, dispatch.retrieve)
                    if result.get("provider_status") not in {"queued", "in_progress"}:
                        break
                    remaining = policy.max_lookups - claim[0]
                    if remaining:
                        next_lookup = time() + max(0, wait_until - time()) / (remaining + 1)
            if stopped(force=True):
                result = dispatch.record_verified_stop(
                    ledger, execution, thread, turn,
                    rollback_stop=host._rollback_stop if args.run_assignment is not None else None,
                )
            if (args.run_assignment is not None and result["status"] != "stopped"
                    and result.get("provider_status") == "completed"):
                result["handoff"] = _deliver_saved(execution, thread, turn)["status"]
            if (dispatch.deliver is not None and result["status"] != "stopped"
                    and result.get("provider_status") == "completed"):
                result["handoff"] = handoff_result(
                    ledger, execution, thread, turn,
                    lambda: _origin(thread, turn) and not stopped(force=True), dispatch.deliver,
                )
            if (result["status"] == "hold_reconciliation"
                    or result.get("handoff") in {"handoff_unconfirmed", "origin_unconfirmed"}):
                watch_args = (rollout, ledger, execution, thread, turn, args.reconcile_seconds)
                if args.run_assignment is not None and attempt:
                    arm_watch(attempt)
                elif dispatch.cancel_project and dispatch.cancel_before and dispatch.cancel_timeout:
                    launch_stop_watch(
                        *watch_args, cancel_project=dispatch.cancel_project,
                        cancel_before=dispatch.cancel_before, cancel_timeout=dispatch.cancel_timeout,
                        **({"rollback": True} if args.run_assignment is not None else {}),
                    )
                else:
                    launch_stop_watch(*watch_args)
            _emit(result)
            return 0 if (result["status"] == "settled"
                         and result.get("handoff", "handed_off") == "handed_off") else 2
    except StartupContractMismatch:
        _emit({"status": "hold", "reason": "core_startup_contract_mismatch"})
        return 2
    except WorkflowUnconfirmed:
        _emit({"status": "hold", "reason": "core_workflow_unconfirmed"})
        return 2
    except AcquisitionError as exc:
        _emit({"status": "hold", "reason": exc.reason})
        return 2
    except (EOFError, OSError, ValueError, KeyError, sqlite3.Error):
        _emit({"status": "hold", "reason": "desktop_admission_unconfirmed"})
        return 2
    _emit({"status": "admission_checked", "execution_id": execution, "created": created})
    return 0


def main(argv: list[str] | None = None, *, dispatch=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--journal", type=Path)
    parser.add_argument("--turn-id", help="Originating Codex turn for a Desktop request")
    parser.add_argument("--core-python", type=Path, help="trusted local Core interpreter")
    parser.add_argument("--core-cache-dir", type=Path)
    parser.add_argument("--core-wheelhouse", type=Path, help="local source for the offline Core cache")
    parser.add_argument("--api-config", type=Path, help="Settings for the no-send admission check")
    parser.add_argument("--request-input", type=Path, help="UTF-8 task input for --check-admission")
    parser.add_argument("--request-id", help="Stable UUID for retries of the same request")
    parser.add_argument("--approve-retry", metavar="PRIOR_ATTEMPT_ID",
                        help="Approve one new generation attempt after proof of non-submission")
    parser.add_argument("--workflow-reference", type=Path, help="Optional Core Workflow reference JSON")
    parser.add_argument("--wait-seconds", type=float, default=5)
    parser.add_argument("--reconcile-seconds", type=float, default=35)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--rollback", action="store_true", help="Block new Desktop Runtime executions")
    action.add_argument("--enable", action="store_true", help="Explicitly restore Desktop Runtime admission")
    action.add_argument("--run-assignment", metavar="ASSIGNMENT_KEY",
                        help="Submit admitted work using the configured purpose budget")
    action.add_argument("--admit-assignment", metavar="ASSIGNMENT_KEY",
                        help="Correlate a host-assigned work item in the current Windows profile")
    action.add_argument("--check-admission", action="store_true", help="Validate and correlate a Desktop request without sending it")
    action.add_argument("--deliver-saved-result", metavar="EXECUTION_ID",
                        help="Offer the saved result to the active originating Desktop turn")
    action.add_argument("--recover-saved-result", metavar="EXECUTION_ID",
                        help="Read a stopped execution from the authenticated Windows owner's journal")
    action.add_argument("--reconcile-desktop-usage", metavar="EXECUTION_ID",
                        help="Reconcile the original response as its authenticated Windows owner")
    arguments = sys.argv[1:] if argv is None else argv
    args = parser.parse_args(arguments)
    if args.approve_retry is not None and (args.run_assignment is None or not args.approve_retry.strip()):
        parser.error("--approve-retry requires --run-assignment and the original unsent attempt ID")
    if args.enable or args.rollback:
        if len(arguments) != 1:
            parser.error("--enable and --rollback each operate alone on the current Windows profile")
        try:
            _emit(host._set_admission(args.enable))
        except (OSError, sqlite3.Error):
            _emit({"status": "hold", "reason": "admission_profile_unavailable"})
            return 2
        return 0
    if args.turn_id is None:
        parser.error("--turn-id is required for a Desktop request")
    if args.run_assignment is not None:
        args.admit_assignment = args.run_assignment
    if args.admit_assignment is not None:
        if (not args.admit_assignment.strip() or args.request_input is None
                or args.request_id is not None or args.journal is not None or args.api_config is not None):
            parser.error("--admit-assignment requires assigned input and uses the current profile settings")
        # The host owns this opaque key and reuses it across retries. Independently
        # supplied origins and request content must still match the first admission.
        args.request_id = str(uuid5(UUID("3cf86d0c-333e-476c-ad5b-76ce15c74006"), args.admit_assignment))
        args.journal = _desktop_journal()
        args.api_config = args.journal.with_name("api.json")
        args.check_admission = True
    if any(value is not None for value in (args.deliver_saved_result, args.recover_saved_result,
                                           args.reconcile_desktop_usage)):
        if args.journal is not None:
            parser.error("Desktop recovery and usage reconciliation use the current Windows profile journal")
    elif args.journal is None:
        parser.error("--journal is required")
    admission_args = (args.api_config, args.request_input, args.request_id, args.workflow_reference)
    if any(value is not None for value in admission_args) and not args.check_admission:
        parser.error("request and API settings require --check-admission")
    if (args.request_input is None) != (args.request_id is None):
        parser.error("--request-input and --request-id must be supplied together")
    if args.workflow_reference is not None and args.request_input is None:
        parser.error("--workflow-reference requires --request-input")
    if not (0 < args.wait_seconds <= 60 and 0 < args.reconcile_seconds <= 60):
        parser.error("wait and reconciliation times must be positive and at most 60 seconds")
    thread, turn = os.environ.get("CODEX_THREAD_ID", ""), args.turn_id
    try:
        if any(str(UUID(value)) != value for value in (thread, turn)):
            raise ValueError
    except ValueError:
        _emit({"status": "hold", "reason": "invalid_origin"})
        return 2
    if args.deliver_saved_result is not None:
        try:
            outcome = _deliver_saved(args.deliver_saved_result, thread, turn)
        except (OSError, sqlite3.Error, ValueError):
            outcome = {"status": "hold", "reason": "saved_result_unavailable"}
        _emit(outcome)
        return 0 if outcome["status"] == "handed_off" else 2
    if args.recover_saved_result is not None:
        execution = args.recover_saved_result

        try:
            outcome = recover_saved_result(
                _desktop_journal(), execution, thread, turn,
                host.authenticated_owner(),
                verify_abort=lambda: host._read_abort(host._local_rollout(thread), turn, 0)[0],
            )
        except (OSError, sqlite3.Error, ValueError):
            outcome = {"status": "hold", "reason": "saved_result_unavailable"}
        _emit(outcome)
        return 0 if outcome["status"] == "result_recovered" else 2
    if args.reconcile_desktop_usage is not None:
        try:
            retrieve = dispatch.retrieve if dispatch else None
            if retrieve is None and _desktop_journal().is_file():
                with closing(sqlite3.connect(_desktop_journal().resolve().as_uri() + "?mode=ro", uri=True)) as db:
                    if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                                  "AND name='desktop_authority_v1'").fetchone():
                        row = db.execute("SELECT policy FROM desktop_authority_v1 WHERE execution=?",
                                         (args.reconcile_desktop_usage,)).fetchone()
                        if row:
                            policy = PurposePolicy(**json.loads(row[0]))
                            retrieve = policy.dispatch(deadline=monotonic()).retrieve
            outcome = reconcile_usage(
                _desktop_journal(), args.reconcile_desktop_usage, thread, turn,
                host.authenticated_owner(), retrieve,
            )
        except (OSError, sqlite3.Error, ValueError):
            outcome = {"status": "hold_reconciliation", "reason": "journal_or_profile_unavailable"}
        _emit(outcome)
        return 0 if outcome["status"] == "settled" else 2
    return _check_admission(args, thread, turn, dispatch=dispatch)
