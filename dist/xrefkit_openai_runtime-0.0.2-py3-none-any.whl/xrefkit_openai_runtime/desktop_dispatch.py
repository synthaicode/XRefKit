"""Persist a Desktop send claim and its budget exposure before provider I/O."""

from collections.abc import Callable
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
import sqlite3
from time import monotonic
from uuid import uuid4

from .desktop_admission import Request


_TERMINAL = frozenset({"completed", "failed", "incomplete", "cancelled"})

# A cancelled response can report zero initially and report usage on later reads.
# Keep old zero-cost cancellation rows reserved until confirmed usage is available.
_SETTLED_COST = "CASE WHEN provider_status = 'cancelled' AND cost = 0 THEN NULL ELSE cost END"


class GenerationNotSent(Exception):
    """The provider generation endpoint has not been invoked."""


@dataclass(frozen=True)
class BudgetQuote:
    purpose: str
    cap_microusd: int
    reservation_microusd: int


@dataclass(frozen=True)
class ProviderReceipt:
    response_id: str
    status: str
    cost_microusd: int | None
    result_text: str | None = None
    background: bool = False


@dataclass(frozen=True)
class DesktopDispatch:
    """The transport and price source are supplied by the Runtime composition root."""

    quote: Callable[[Request], BudgetQuote]
    submit: Callable[[str, Request], ProviderReceipt]
    deliver: Callable[[str, str, str], bool] | None = None
    cancel: Callable[[str], ProviderReceipt] | None = None
    cancel_before: float | None = None
    retrieve: Callable[[str], ProviderReceipt] | None = None
    cancel_project: str | None = None
    cancel_timeout: float | None = None

    def execute(
        self, journal: Path, execution: str, request: Request,
        can_send: Callable[[], bool], *, retry_of: str | None = None,
        arm_watch: Callable[[str], None] | None = None,
        stopped_origin: Callable[[], tuple[str, str] | None] | None = None,
    ) -> dict:
        with closing(sqlite3.connect(journal)) as db:
            return self._execute(db, execution, request, can_send, retry_of, arm_watch, stopped_origin)

    def _execute(self, db, execution, request, can_send, retry_of, arm_watch, stopped_origin):
        with db:
            db.execute("BEGIN IMMEDIATE")
            _prepare_dispatch(db)
            if _stopped(db, execution):
                return _stop_outcome(execution, _read_submission(db, execution))
            existing = _read_submission(db, execution)
            attempt = None
            if existing is not None:
                attempt, predecessor = _current_attempt(db, execution, existing)
                if retry_of is None or retry_of == predecessor:
                    return dict(_outcome(execution, *existing), attempt_id=attempt)
            if retry_of is not None and (retry_of != attempt or existing != (None, "not_submitted", 0)):
                return {"status": "hold", "reason": "retry_not_eligible", "execution_id": execution}
            if not can_send():
                return {"status": "hold", "reason": "desktop_send_disabled", "execution_id": execution}
            quote = self.quote(request)
            if not quote.purpose or not all(
                type(value) is int and 0 <= value < 2**63
                for value in (quote.cap_microusd, quote.reservation_microusd)
            ) or quote.reservation_microusd == 0:
                return {"status": "hold", "reason": "budget_unconfirmed", "execution_id": execution}
            used = db.execute(
                "SELECT coalesce(sum(coalesce(" + _SETTLED_COST + ", reservation)), 0) "
                "FROM desktop_submission_v1 WHERE purpose = ?", (quote.purpose,),
            ).fetchone()[0]
            if quote.reservation_microusd > quote.cap_microusd - used:
                return {"status": "hold", "reason": "budget_exceeded", "execution_id": execution}
            if not can_send():
                return {"status": "hold", "reason": "desktop_send_disabled", "execution_id": execution}
            attempt = uuid4().hex
            db.execute(
                "INSERT INTO desktop_attempt_v1(attempt_id, execution, retry_of, purpose, reservation) "
                "VALUES(?, ?, ?, ?, ?)", (attempt, execution, retry_of, quote.purpose, quote.reservation_microusd),
            )
            # Only a proved-unsent, zero-cost predecessor can be replaced. The ledger
            # continues to charge the current claim; history retains each reservation.
            db.execute("""
                INSERT INTO desktop_submission_v1(execution, purpose, reservation) VALUES(?, ?, ?)
                ON CONFLICT(execution) DO UPDATE SET purpose=excluded.purpose, reservation=excluded.reservation,
                    cost=NULL, provider_status=NULL
                """, (execution, quote.purpose, quote.reservation_microusd))

        # Once committed, a crash or ambiguous transport failure keeps the full reservation.
        # A later invocation can inspect the claim, but cannot submit it again.
        if arm_watch is not None:
            try:
                arm_watch(attempt)
            except (OSError, sqlite3.Error):
                with db:
                    _record_unsent(db, execution, attempt, stopped_origin)
                return dict(_outcome(execution, None, "not_submitted", 0), attempt_id=attempt)
        allowed = can_send()
        if not allowed or _stopped(db, execution):
            with db:
                db.execute("BEGIN IMMEDIATE")
                _record_unsent(db, execution, attempt, stopped_origin)
                stopped = _stopped(db, execution)
            if stopped:
                return _stop_outcome(execution, None)
            return {"status": "hold", "reason": "desktop_send_disabled", "execution_id": execution,
                    "attempt_id": attempt}
        try:
            receipt = self.submit(execution, request)
        except GenerationNotSent:
            with db:
                _record_unsent(db, execution, attempt, stopped_origin)
            return dict(_outcome(execution, None, "not_submitted", 0), attempt_id=attempt)
        except OSError:
            return dict(_outcome(execution, None, None, None), attempt_id=attempt)
        if not receipt.response_id or not receipt.status:
            return dict(_outcome(execution, None, None, None), attempt_id=attempt)
        with db:
            db.execute("BEGIN IMMEDIATE")
            _record_receipt(db, execution, quote.reservation_microusd, receipt)
            if receipt.background is True:
                db.execute("INSERT INTO desktop_background_v1 VALUES (?)", (execution,))
        return dict(_outcome(execution, *_read_submission(db, execution)), attempt_id=attempt)

    def record_verified_stop(self, journal: Path, execution: str, thread: str, turn: str, *, rollback_stop=None) -> dict:
        """Record a Stop already verified by the host for this exact local turn."""
        return record_verified_stop(
            journal, execution, thread, turn, cancel=self.cancel, cancel_before=self.cancel_before,
            rollback_stop=rollback_stop,
        )

    def record_retrieved_receipt(
        self, journal: Path, execution: str, receipt: ProviderReceipt,
    ) -> dict:
        """Apply a receipt from internal reconciliation of the recorded response."""
        with closing(sqlite3.connect(journal)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            _prepare_dispatch(db)
            return apply_retrieved_receipt(db, execution, receipt)


def record_verified_stop(
    journal: Path, execution: str, thread: str, turn: str, *,
    cancel: Callable[[str], ProviderReceipt] | None = None, cancel_before: float | None = None,
    watch_attempt: str | None = None, rollback: Callable[[], None] | None = None,
    rollback_stop: Callable[..., None] | None = None,
    watch_until: float | None = None,
) -> dict:
    with closing(sqlite3.connect(journal.resolve().as_uri() + "?mode=rw", uri=True)) as db:
        with db:
            db.execute("BEGIN IMMEDIATE")
            _prepare_dispatch(db)
            origin = db.execute("SELECT thread, turn FROM desktop_request_v1 WHERE execution = ?",
                                (execution,)).fetchone()
            if origin != (thread, turn):
                return {"status": "hold", "reason": "origin_unconfirmed", "execution_id": execution}
            if watch_until is not None and monotonic() >= watch_until:
                return {"status": "hold", "reason": "watch_expired", "execution_id": execution}
            if watch_attempt is not None and not _watch_active(db, execution, watch_attempt):
                return {"status": "hold", "reason": "watch_retired", "execution_id": execution}
            prior = _read_submission(db, execution)
            eligible = bool(prior and prior[0] and prior[1] in {"queued", "in_progress"}
                            and cancel and cancel_before is not None and monotonic() < cancel_before
                            and db.execute("SELECT 1 FROM desktop_background_v1 WHERE execution=?",
                                           (execution,)).fetchone())
            # Only the first durable Stop can claim a cancellation. Previously observed
            # Stops (including legacy rows) cannot gain authority from a later receipt.
            first_stop = db.execute(
                "INSERT INTO desktop_stop_v1(execution, cancel_claimed, scoped_rollback) VALUES (?, ?, 1) "
                "ON CONFLICT DO NOTHING", (execution, int(eligible)),
            ).rowcount
            legacy = not first_stop and db.execute(
                "SELECT scoped_rollback FROM desktop_stop_v1 WHERE execution=?", (execution,),
            ).fetchone() == (0,)
        try:
            if rollback_stop is not None:
                rollback_stop(execution, legacy=legacy)
            elif rollback is not None:
                rollback()
        finally:
            if first_stop and eligible and monotonic() < cancel_before:
                try:
                    receipt = cancel(prior[0])
                except OSError:
                    receipt = None
                if receipt and receipt.response_id == prior[0] and receipt.status in _TERMINAL:
                    with db:
                        db.execute("BEGIN IMMEDIATE")
                        apply_retrieved_receipt(db, execution, receipt)
        return _stop_outcome(execution, _read_submission(db, execution))


def apply_retrieved_receipt(db, execution: str, receipt: ProviderReceipt) -> dict:
    """Apply matching evidence using the caller's write transaction."""
    prior = db.execute(
        f"SELECT response_id, provider_status, {_SETTLED_COST}, reservation "
        "FROM desktop_submission_v1 WHERE execution = ?", (execution,),
    ).fetchone()
    if prior is None or prior[0] is None or prior[0] != receipt.response_id:
        return {"status": "hold", "reason": "response_unconfirmed", "execution_id": execution}
    response_id, status, cost, reservation = prior
    if status == "queued" and receipt.status == "in_progress":
        db.execute("UPDATE desktop_submission_v1 SET provider_status=? WHERE execution=?",
                   (receipt.status, execution))
        return _outcome(execution, response_id, receipt.status, cost)
    if receipt.status not in _TERMINAL or (status in _TERMINAL and status != receipt.status):
        return _outcome(execution, response_id, status, cost)
    if cost is not None:
        # A later read may supply the result after billing has already settled.
        _save_result(db, execution, receipt)
        return _outcome(execution, response_id, status, cost)
    _record_receipt(db, execution, reservation, receipt)
    return _outcome(execution, *_read_submission(db, execution))

def _watch_active(db, execution, attempt):
    current = db.execute("SELECT attempt_id, not_sent FROM desktop_attempt_v1 WHERE execution=? "
                         "ORDER BY sequence DESC LIMIT 1", (execution,)).fetchone()
    if current is None or current[0] != attempt:
        return False
    if _stopped(db, execution):
        return True  # Finish rollback after a foreground stop or failed profile write.
    if current[1]:
        return False
    submission = _read_submission(db, execution)
    if submission and submission[1] in {"failed", "cancelled", "incomplete"}:
        return False
    has_handoff = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                             "AND name='desktop_handoff_v1'").fetchone()
    return not (has_handoff and db.execute("SELECT 1 FROM desktop_handoff_v1 "
                                            "WHERE execution=? AND completed=1", (execution,)).fetchone())


def restore_stop_for_recovery(db, execution: str, verify_abort: Callable[[], bool]) -> bool | None:
    """Resolve Stop evidence within the authorized recovery writer transaction."""
    _prepare_stops(db)
    saved = db.execute("SELECT scoped_rollback FROM desktop_stop_v1 WHERE execution=?", (execution,)).fetchone()
    if saved is not None:
        return not bool(saved[0])
    if not verify_abort():
        return None
    db.execute("INSERT INTO desktop_stop_v1(execution, scoped_rollback) VALUES (?, 1)", (execution,))
    return False


def _prepare_stops(db):
    db.execute("""
        CREATE TABLE IF NOT EXISTS desktop_stop_v1 (
            execution TEXT PRIMARY KEY, cancel_claimed INTEGER NOT NULL DEFAULT 0,
            scoped_rollback INTEGER NOT NULL DEFAULT 0
        )
    """)
    if not any(row[1] == "scoped_rollback" for row in db.execute("PRAGMA table_info(desktop_stop_v1)")):
        db.execute("ALTER TABLE desktop_stop_v1 ADD COLUMN scoped_rollback INTEGER NOT NULL DEFAULT 0")


def _prepare_dispatch(db):
    db.execute("""
        CREATE TABLE IF NOT EXISTS desktop_attempt_v1 (
            sequence INTEGER PRIMARY KEY, attempt_id TEXT UNIQUE NOT NULL, execution TEXT NOT NULL,
            retry_of TEXT UNIQUE, purpose TEXT NOT NULL, reservation INTEGER NOT NULL,
            not_sent INTEGER NOT NULL DEFAULT 0
        )
    """)
    db.execute("CREATE INDEX IF NOT EXISTS desktop_attempt_execution ON desktop_attempt_v1(execution, sequence)")
    db.execute("""
        CREATE TABLE IF NOT EXISTS desktop_submission_v1 (
            execution TEXT PRIMARY KEY, purpose TEXT NOT NULL,
            reservation INTEGER NOT NULL, response_id TEXT UNIQUE,
            provider_status TEXT, cost INTEGER
        )
    """)
    db.execute("CREATE TABLE IF NOT EXISTS desktop_background_v1 (execution TEXT PRIMARY KEY)")
    _prepare_stops(db)


def _current_attempt(db, execution, existing):
    row = db.execute("SELECT attempt_id, retry_of FROM desktop_attempt_v1 WHERE execution=? ORDER BY sequence DESC LIMIT 1",
                     (execution,)).fetchone()
    if row is not None:
        return row
    # Older journals have one send claim per execution and no attempt identity.
    # Adopt that claim without modifying its exposure, response or settlement.
    attempt = uuid4().hex
    db.execute("""
        INSERT INTO desktop_attempt_v1(attempt_id, execution, purpose, reservation, not_sent)
        SELECT ?, execution, purpose, reservation, ? FROM desktop_submission_v1 WHERE execution=?
        """, (attempt, existing == (None, "not_submitted", 0), execution))
    return attempt, None


def _record_unsent(db, execution, attempt, stopped_origin):
    db.execute("UPDATE desktop_submission_v1 SET provider_status='not_submitted', cost=0 "
               "WHERE execution=? AND response_id IS NULL", (execution,))
    db.execute("UPDATE desktop_attempt_v1 SET not_sent=1 WHERE attempt_id=?", (attempt,))
    origin = stopped_origin() if stopped_origin is not None else None
    if origin:
        db.execute("INSERT OR IGNORE INTO desktop_stop_v1(execution, scoped_rollback) "
                   "SELECT execution, 1 FROM desktop_request_v1 WHERE execution=? AND thread=? AND turn=?",
                   (execution, *origin))


def _stopped(db, execution):
    return db.execute("SELECT 1 FROM desktop_stop_v1 WHERE execution = ?", (execution,)).fetchone() is not None


def _stop_outcome(execution, prior):
    return {**_outcome(execution, *(prior or (None, None, None))), "status": "stopped"}


def _read_submission(db, execution):
    return db.execute(
        f"SELECT response_id, provider_status, {_SETTLED_COST} FROM desktop_submission_v1 WHERE execution = ?",
        (execution,),
    ).fetchone()


def _record_receipt(db, execution, reservation, receipt):
    terminal = receipt.status in _TERMINAL
    cost = receipt.cost_microusd
    if (not terminal or type(cost) is not int or not 0 <= cost <= reservation
            or receipt.status == "cancelled" and cost == 0):
        cost = None
    db.execute(
        "UPDATE desktop_submission_v1 SET response_id = ?, provider_status = ?, "
        f"cost = coalesce({_SETTLED_COST}, ?) WHERE execution = ?",
        (receipt.response_id, receipt.status, cost, execution),
    )
    _save_result(db, execution, receipt)


def _save_result(db, execution, receipt):
    if receipt.status == "completed" and receipt.result_text is not None:
        db.execute("""
            CREATE TABLE IF NOT EXISTS desktop_result_v1 (
                execution TEXT PRIMARY KEY REFERENCES desktop_submission_v1(execution),
                result_text TEXT NOT NULL
            )
        """)
        db.execute(
            "INSERT INTO desktop_result_v1 VALUES (?, ?) ON CONFLICT(execution) DO NOTHING",
            (execution, receipt.result_text),
        )


def _outcome(execution, response_id, provider_status, cost):
    if provider_status == "not_submitted":
        return {"status": "hold", "reason": "generation_preflight_failed", "execution_id": execution,
                "response_id": None, "provider_status": provider_status, "cost_microusd": 0}
    return {"status": "settled" if cost is not None else "hold_reconciliation",
            "execution_id": execution, "response_id": response_id,
            "provider_status": provider_status, "cost_microusd": cost}
